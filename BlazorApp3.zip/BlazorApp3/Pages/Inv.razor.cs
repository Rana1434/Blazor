﻿using BlazorApp3.Models;
using Microsoft.AspNetCore.Components;

namespace BlazorApp3.Pages
{
    public partial class Inv
    {
        
        public bool ShowInvoice { get; set; } = false;
        public List<Invoice> InvoiceList {  get; set; } = new List<Invoice>();
        public Invoice NewInvoice { get; set; }=new Invoice();
        
        [Inject]
        public EmployeeDbContext invDbcontext { get; set; } = default!;
        protected override void OnInitialized()
        {
         
            
                //InvoiceList = invDbcontext.Invoices.ToList();
                StateHasChanged();
            

        }

        public async Task Submit()
        {

            ShowInvoice = true;
            try
            {
                //invDbcontext.Invoices.Add(NewInvoice);
                //invDbcontext.SaveChanges();
                //InvoiceList = invDbcontext.Invoices.ToList().ToList();
                InvoiceList.Add(NewInvoice);
                StateHasChanged();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
