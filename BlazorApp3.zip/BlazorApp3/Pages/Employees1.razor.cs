﻿using BlazorApp3.Models;
using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;

namespace BlazorApp3.Pages
{
    public partial class Employees1
    {
        public List<Employee> ListOfEmployees { get; set; }
        public bool ShowAddEmployee { get; set; } = false;
        public Employee NewEmployee { get; set; } = new Employee();

        [Inject]
        public EmployeeDbContext employeeDbcontext { get; set; } = default!;

        // List<Employees> employees = new();
        protected override void OnAfterRender(bool firstRender)
        {
            if (firstRender)
            {
                ListOfEmployees = employeeDbcontext.Employees.ToList();
                StateHasChanged();
            }

        }
        public async Task DeleteEmployee(int id)
        {
            bool result = await Js.InvokeAsync<bool>("confirm", "Are you sure to delete?");

            if (result == true)
            {
                var e = employeeDbcontext.Employees.FirstOrDefault(x => x.Id == id);
                employeeDbcontext.Employees.Remove(e);
                employeeDbcontext.SaveChanges();
                ListOfEmployees = employeeDbcontext.Employees.ToList();
            }
        }
        public async Task AddEmployeeForm()
        {
            NewEmployee = new Employee();
            ShowAddEmployee = true;
        }
        public async Task HideAddEmp()
        {
            ShowAddEmployee = false;
        }
        public async Task SaveEmployee()
        {
            ShowAddEmployee = false;
            try
            {
                employeeDbcontext.Employees.Add(NewEmployee);
                employeeDbcontext.SaveChanges();
                ListOfEmployees = employeeDbcontext.Employees.ToList();
                StateHasChanged();


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
