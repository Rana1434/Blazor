using BlazorApp3.Data;
using BlazorApp3.Models;
using BlazorApp3.Pages;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;

namespace BlazorApp3
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            builder.Configuration.AddJsonFile("appsettings.json", optional: false, reloadOnChange: false);
            var _configuration = builder.Configuration;


            // Add services to the container.
            builder.Services.AddRazorPages();
            builder.Services.AddServerSideBlazor();
            builder.Services.AddSingleton<WeatherForecastService>();
            builder.Services.AddSingleton<Employees1>();
            builder.Services.AddSingleton<Inv>();

            builder.Services.AddDbContextFactory<EmployeeDbContext>((ServiceProvider, options) =>
            {
                options.UseSqlServer(_configuration["Connectionstrings:SqlConnection"]);
            }, ServiceLifetime.Transient);
            builder.Services.AddDbContextFactory<EmployeeDbContext>((ServiceProvider, options) =>
            {
                options.UseSqlServer(_configuration["Connectionstrings:SqlConnection1"]);
            }, ServiceLifetime.Transient);

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Error");
            }


            app.UseStaticFiles();

            app.UseRouting();

            app.MapBlazorHub();
            app.MapFallbackToPage("/_Host");

            app.Run();
        }
    }
}