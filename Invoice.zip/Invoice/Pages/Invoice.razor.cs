﻿namespace Invoice.Pages
{
    public partial class Invoice
    {

        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
        public bool ShowInvoice { get; set; } = false;
        public List<Invoice>? Details { get; set; }
        public Invoice NewInvoice { get; set; } = new Invoice();
        protected override void OnAfterRender(bool firstRender)
        {
            if (firstRender)
            {
                Details = new List<Invoice>();
            };
        }
        public async Task Submit()
        {
            Details = new List<Invoice>();
            NewInvoice = new Invoice();
            ShowInvoice = true;
            var inv = Details;
            NewInvoice.Id = Details.Count + 1;
            inv.Add(NewInvoice);
            Details = inv;
        }
    }
}
